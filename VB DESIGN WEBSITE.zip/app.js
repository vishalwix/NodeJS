const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const path = require('path');
const nodemailer = require('nodemailer');

const app = express();

// View engine setup
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');

// Static folder
app.use('/public', express.static(path.join(__dirname, 'public')));

// Body Parser Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.render('contact');
});

app.post('/send', (req, res) => {
  const output = `
    <h3 style="color:blue">Contact Details</h3>
    <ul>  
      <li><h4>Name :  ${req.body.name}</h4></li>
      <li><h4>Subject :  ${req.body.company}</h4></li>
      <li><h4>Email :  ${req.body.email}</h4></li>
      <li><h4>Phone :  ${req.body.phone}</h4></li>
    </ul>
    <h3 style="color:blue">Message</h3>
    <h4>${req.body.message}</h4>
  `;

  const output1 = `    
    <h3 style="color:blue">Thank you for getting in touch! </h3>
    <p style="color:#636362">We appreciate you contacting us. One of our customer happiness members will get back in touch with you soon! <br><br> Thank you for your patience..! Have a great day! </p>
    <h4><br>Team,<br>VB DESIGN.</h4>
    `;

  const mailId = `${req.body.email}`;
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "sg3plcpnl0039.prod.sin3.secureserver.net",  
    secureConnection: true,
    port: 465,
      auth: {
          user: "",
          pass: ""
      }
  });

  // setup email data with unicode symbols
  let mailOptions = {
      from: 'VB DESIGN Contact <no-reply@vbdesign.in>',
      to: 'vishalwix6@gmail.com',
      subject: req.body.name+" - "+'Wants to reach you.',
      text: 'Hello world?', // plain text body
      html: output // html body
  };

  let mailOptions1 = {
    from: 'VB DESIGN Contact <no-reply@vbdesign.in>',
    to: mailId,
    subject: 'VB DESIGN Contact | Thank you for contacting with us..!',
    text: 'Hello world?', // plain text body
    html: output1 // html body
};

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
          return console.log(error);
      }
      
      transporter.sendMail(mailOptions1, (error, info) => {
        if (error) {
          res.render('contact', {msgErr:'We are facing some error..! Try after some tome'});
        }else{
        console.log('Message sent: %s', info.messageId);   
        }      
      });

      console.log('Message sent: %s', info.messageId);   
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

      res.render('contact', {msg:'Your contact info has been sent successfully...!'});
  });
  });

app.listen(8000, () => console.log('Server started...'));